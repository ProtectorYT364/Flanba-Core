# Flanba-Core

# TODO LIST

* BRIDGE Basics

  - (done) Goal system (block id for red team goal, and blue team goal, just like what Phqzing did)
  - (done)1v1, 2v2. 3v3, 4v4
  - (done) Safezone
  - (done) height limit
  - (done)customizable inventory 
  - (done)bow cooldown (with moving xp bar as counter)
  - (done)gapple cooldown (moving xp bar)
  - give  coins whenver u goal
  - Leveling System (also display ur level on ur xp bar)
  - Prestige system (Iron, Gold, Diamond, Amethyst, Godlike, bridge #1, bridge #2, bridge #3)    (can be unlock if u reach certain amount pf wins)
  - Buyable goal design, (kind like hypixel where u can buy fire goal, pig spawner goal, etc.)


* Leaderboards

  - Goals Leaderboards
  - wins Leaderboards
  - best winstreaks leaderboard

* PARTY SYSTEM (Developed as a different plugin which needs the integrations below in this core)

 - List of Commands to make from PartyEngine API:
     i. /p
     ii. /p duel
     iii. /p list
  
* STORE

  - You can buy Cages
  - buy Win effects such as (riding an enderdragon, wither, ur skin keep crouching, riding a bee, etc.)
  - ^^^^ Can be bought withcoins
  
  
* cosmetics

  - Wings
  - Capes
  - coatume
  - ^^^ Can be unlock if u reach ceratin level

* RANKS

  - All Basic Ranks stuff 


        NameTag Prefix:    [Level] [Prestige] [Name with custom color]  }
                               CPS: 28 | Ping: 69                } Show up when they're in combat . If not in combat do this ANDROID | TOUCH
        
        Chat Prefix:   [Level] [Prestige] [Rank] [name]: [msg]
# WILL ADD MORE SOON
